//
//  TVViewController.swift
//  gym
//
//  Created by Xcode on 5/24/21.
//  Copyright © 2021 Xcode. All rights reserved.
//

import UIKit

class TVViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var newItemTF: UITextField!
    
    @IBOutlet weak var tableView: UITableView!
    
    var Workouts: [Item] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.dataSource = self
        let Workout1 = Item(name: "Bench Press", points: 32)
        let Workout2 = Item(name: "Squat", points: 54)
        let Workout3 = Item(name: "Deadlift", points: 15)
        Workouts = [Workout1, Workout2, Workout3]
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Workouts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
               let currentItem = Workouts[indexPath.row]
               
               cell.textLabel?.text = currentItem.name
               cell.detailTextLabel?.text = "Points \(currentItem.points)"
               return cell
           }
    
    @IBAction func addButton(_ sender: UIBarButtonItem) {
        if let newItemName = newItemTF.text
               {
                   let newItem = Item(name: newItemName, points: 17)
                   Workouts.append(newItem)
                   tableView.reloadData()
                   newItemTF.text = ""
               }
    }
}
