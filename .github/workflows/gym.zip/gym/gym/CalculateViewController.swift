//
//  CalculateViewController.swift
//  gym
//
//  Created by Xcode on 5/23/21.
//  Copyright © 2021 Xcode. All rights reserved.
//

import UIKit

class CalculateViewController: UIViewController {

    @IBOutlet weak var finalAnswer: UILabel!
    
    @IBOutlet weak var weightTF: UITextField!
    
    @IBOutlet weak var heightTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    @IBAction func calculateButton(_ sender: UIButton) {
        let Weight = Double(weightTF.text!)!
        let Height = Double(heightTF.text!)!
        let h = Height * Height
        let bmi = ((Weight / h) * 703)
        if bmi >= 0 && bmi <= 15
        {
            finalAnswer.text = "underweight"
        }
        else if bmi >= 16 && bmi <= 22 {
            finalAnswer.text = "average"
        }
        else {
            finalAnswer.text = "overweight"
        }
    }
    
}
