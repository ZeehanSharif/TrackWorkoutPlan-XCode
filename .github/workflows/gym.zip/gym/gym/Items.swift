//
//  Items.swift
//  gym
//
//  Created by Xcode on 5/24/21.
//  Copyright © 2021 Xcode. All rights reserved.
//

import Foundation

class Item
{
    var name: String
    var points: Int
    init(name: String, points: Int) {
        self.name = name
        self.points = points
    }
}

