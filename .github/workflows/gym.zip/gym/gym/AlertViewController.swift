//
//  AlertViewController.swift
//  gym
//
//  Created by Xcode on 5/24/21.
//  Copyright © 2021 Xcode. All rights reserved.
//

import UIKit
import SafariServices

class AlertViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    @IBAction func clickMeButton(_ sender: UIBarButtonItem) {
        let alert = UIAlertController(title: "SIGN UP FOR A GYM", message: "so you can actually do the workouts", preferredStyle: .alert)
        
         let ok = UIAlertAction(title: "Ok", style: .cancel)
        
         alert.addAction(ok)
         self.present(alert, animated: true, completion: nil)
    }
    @IBAction func dietButton(_ sender: UIButton) {
        let url = URL(string: "https://www.cdc.gov/healthyweight/healthy_eating/index.html#:~:text=According%20to%20the%20Dietary%20Guidelines,fat%20milk%20and%20milk%20products")!
        
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
        
    }
    
}
