//
//  ViewController.swift
//  gym
//
//  Created by Xcode on 5/23/21.
//  Copyright © 2021 Xcode. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func segueButton(_ sender: UIButton) {
       
    }
    
}

